module.exports = {
    userService: require('./userService'),
    authService: require('./authService'),
    countryLanguagesService: require('./countryLanguagesService'),
    communityService: require('./communityService'),
    careReceiverService: require('./careReceiverService'),
    documentService: require('./documentService'),
};