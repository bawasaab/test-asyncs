module.exports = {
    userController: require('./userController'),
    authController: require('./authController'),
    CountryLanguagesController: require('./CountryLanguagesController'),
    communityController: require('./communityController'),
    careReceiverController: require('./careReceiverController'),
    documentController: require('./documentController'),
};