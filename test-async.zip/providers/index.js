module.exports = {
    userProvider: require('./userProvider')
};