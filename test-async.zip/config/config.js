const mongodbUrl = 'mongodb://localhost:27017/iGetHappy';

module.exports = {
    mongodbUrl
};