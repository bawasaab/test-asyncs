module.exports = {
    userModel: require('./userModel'),
    countryModel: require('./countryLanguagesModel'),
    PostModel: require('./postModel'),
    PostLikesModel: require('./postLikesModel'),
    CareReceiverModel: require('./careReceiverModel'),
    DocumentModel: require('./documentModel')
};